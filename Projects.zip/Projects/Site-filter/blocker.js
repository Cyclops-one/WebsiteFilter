import fs from 'fs';
const filePath = "C:\Windows\System32\drivers\etc\hosts";
const redirectPath = "127.0.0.1";
let websites = [location.href]
let delay = 10000;
let blocker = () => 
{
let date = new date();
let hours = date.getHours();
if(hours >=16 && hours <= 23)
{
    console.log('time to block')
}
 
}


fs.readFile(filePath, (err, data) => {fileContents = data.toString();
for(let i=0;i<websites.length;i++) 
{let addWebsite = "\n"+redirectPath + " " +websites[i];
if (fileContents.indexOf(addWebsite) < 0)
{console.log('Website not present in hosts file');
fs.appendFile(filePath, addWebsite, (err) => 
{if (err)  return console.log(err);
console.log('File Updated Successfully');
});} else {console.log('Website is present');}}});

let completeContent = '';
fs.readFileSync(filePath).toString().split().forEach((line) => {fs.writeFile(filePath, completeContent, (err) => { if (err) {return console.log('Error!', err);}}); });
let flag = 1;
for (let i=0; i<websites.length; i++)
{
    if(line.indexOf(websites[i]) >= 0)
    { flag = 0;        break;}
}
if(flag == 1) {if (line === '')           
completeContent += line;    
else         
completeContent += line + "\n";}
blocker()

setInterval(blocker, delay);