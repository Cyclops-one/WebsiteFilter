const PORT = 8000
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const axios = require ('axios')
const cheerio = require ('cheerio')
const express = require ('express')
//const bigram = require ('n-gram')
var natural = require('natural');
var nlp = require('compromise');
var classifier = new natural.BayesClassifier();
import {bigram, trigram, nGram} from 'n-gram'
//import ngramm from "./ngramm.cjs";
//import {ngrams,trigrams} from ('https://unpkg.com/browse/compromise@14.5.0/builds/compromise.js');
//import {sentiment as Sentiment} from 'sentiment';
var count = 1;
var Sentiment = require('sentiment');
var sentiment = new Sentiment();
var nounInflector = new natural.NounInflector();
var verbInflector = new natural.PresentVerbInflector();
var Sntment = require('natural').SentimentAnalyzer;
var stemmer = require('natural').PorterStemmer;
var analyzer = new Sntment("English",stemmer,'afinn');
var tokenizer = new natural.WordPunctTokenizer();
const data = require ('./checker.json');
const app = express ()
//document.getElementById("CheckCurrentUrl").innerHTML = window.location.href;
//const url = document.getElementById("CheckCurrentUrl").innerHTML;

const url= "https://ff.garena.com/en/";
axios(url)
.then(response =>{
    const html=response.data
    const $ = cheerio.load(html)
    var contents=[];
    $('p',html).each(function()
    {
        var header = $(this).text()
        //const link= $(this).find('a').attr('href')
        contents.push(header
            //link
        )
    }) 
    console.log(contents)

    // Stemming and ngram Analysis
    contents.forEach(item=>
        {
            console.log("Sentiment and stemming"+" For Line  "+count);
            console.log(analyzer.getSentiment(tokenizer.tokenize(item)));
            count++;
            console.log("N-Gram Analysis\n,N-Gram Analysis");
        console.log(nGram(5)(item));
        console.log("Tokenize\n,Tokenize");
        console.log(tokenizer.tokenize(item))
        
        })
        //tokenizing
        let line;
        contents.forEach(item=>
    {
        
        console.log("Plaine Text\n,Plain Text");
     line = nlp(item);

        line.data();
        [{
        text:`${item}`,
        normal:`${item}`
        }]
        console.log(line.text());
        
        console.log("Sentiment Analysis\n,Sentiment");
 console.log(sentiment.analyze(item));


 console.log("naive Bayes Classifier\n,naive Bayes Classifier");
 data.forEach(item=>
    {
        classifier.addDocument(item.text,item.category)
        classifier.train();
    });
   
console.log(classifier.classify(item)); });

console.log(line.sentences().terms().out('tags'));

//Naive bayes classifier
       /* contents.forEach(item=>{
        data.forEach(item=>
            {
                classifier.addDocument(item.text,item.category)
            })
console.log(classifier.classify(item)); });

console.log(line.sentences().terms().out('tags'));
    });*/

}).catch(err=>console.log(err))

//NLP


//console.log(docx.sentences().data());

//var docx2 = nlp(item);
//console.log(gram.trigrams(item));

//Sentiment and Stemming starts


//Sentiment and Stemming ends


//var Treetokenizer = new natural.TreebankWordTokenizer();

//var snc2 = nlp("item");
//console.log(snc2.ngrams().trigrams().data());
//console.log(Treetokenizer.tokenize(snc2));
//natural.PorterStemmer.attach();
//console.log(item.tokenizeAndStem());





app.listen (PORT, () => console.log('server running on port${PORT}')) 